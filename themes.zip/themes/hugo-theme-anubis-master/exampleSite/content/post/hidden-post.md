+++
author = "Dmitry Kolosov"
title = "Hidden Post"
date = "2021-12-24"
description = "Post available only by link"
tags = [
    "privacy"
]
hidden = true
+++

This is hidden post